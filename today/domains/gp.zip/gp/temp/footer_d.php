<section id="bottom">
    <div class="container wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
     
    </div>
  </section>
  <!--/#bottom-->

  <div class="top-bar">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="social">
            <ul class="social-share">
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
              <li><a href="#"><i class="fa fa-skype"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!--/.container-->
  </div>
  <!--/.top-bar-->
<footer id="footer" class="midnight-blue">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          &copy; Copyright. Все права защищены. @ РеКадр 2020
          <div class="credits">
            <!--
              All the links in the footer should remain intact.
              You can delete the links only if you purchased the pro version.
              Licensing information: https://bootstrapmade.com/license/
              Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Gp
            -->
           
          </div>
        </div>
        <div class="col-sm-6">
          <ul class="pull-right">
          <li><a href="dir.php">Главная</a></li>
            <li><a href="spisok_s.php">Список клиентов (по профессии)</a></li>
            <li><a href="vak_po_pr.php">Вакансии по профессии на дату</a></li>
            <li><a href="otchet_r.php">Список работодателей</a></li>
            <li><a href="otchet_s.php">Список трудоустроенных</a></li>
            <li><a href="reiting_p.php">Рейтинг профессий</a></li>
            <li><a href="reiting_r.php">Рейтинг работодателей</a></li>
            <li><a href="sv.php">Сводный отчет по агентству</a></li>
            <li><a href="out.php">Выход</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <!--/#footer-->