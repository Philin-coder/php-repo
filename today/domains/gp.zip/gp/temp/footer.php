<section id="bottom">
    <div class="container wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
     
    </div>
  </section>
  <!--/#bottom-->

  <div class="top-bar">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="social">
            <ul class="social-share">
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
              <li><a href="#"><i class="fa fa-skype"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!--/.container-->
  </div>
  <!--/.top-bar-->
<footer id="footer" class="midnight-blue">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          &copy; Copyright. Все права защищены. @ РеКадр 2020
          <div class="credits">
            <!--
              All the links in the footer should remain intact.
              You can delete the links only if you purchased the pro version.
              Licensing information: https://bootstrapmade.com/license/
              Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Gp
            -->
           
          </div>
        </div>
        <div class="col-sm-6">
          <ul class="pull-right">
          <li class="active"><a href="index.php">Главная</a></li>
            <li><a href="ocom.php">О компании</a></li>
            <li><a href="vak.php">Вакансии</a></li>
            <li><a href="soisk.php">Соискателю</a></li>
            <li><a href="kon.php">Контакты</a></li>
            <li><a href="avt.php">Вход</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <!--/#footer-->