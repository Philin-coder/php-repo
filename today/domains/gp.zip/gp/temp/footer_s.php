<section id="bottom">
    <div class="container wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
     
    </div>
  </section>
  <!--/#bottom-->

  <div class="top-bar">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="social">
            <ul class="social-share">
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
              <li><a href="#"><i class="fa fa-skype"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!--/.container-->
  </div>
  <!--/.top-bar-->
<footer id="footer" class="midnight-blue">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          &copy; Copyright. Все права защищены. @ РеКадр 2020
          <div class="credits">
            <!--
              All the links in the footer should remain intact.
              You can delete the links only if you purchased the pro version.
              Licensing information: https://bootstrapmade.com/license/
              Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Gp
            -->
           
          </div>
        </div>
        <div class="col-sm-6">
          <ul class="pull-right">
          <li><a href="spec.php">Главная</a></li>
            <li><a href="rab.php">Работодатели</a></li>
            <li><a href="vak_s.php">Вакансии</a></li>
            <li><a href="soisk_s.php">Соискатели</a></li>
            <li><a href="napr.php">Направления</a></li>
            <li><a href="rez_n.php">Результаты направлений</a></li>
            <li><a href="out.php">Выход</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <!--/#footer-->