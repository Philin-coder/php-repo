<?php 
include 'temp/head.php';
include 'temp/header_a.php'; 
 ?>
  <div class="slider">
    <div class="container">
     <div class="center wow fadeInDown">
        <h2>Страница администратора</h2>
     </div>
     <div class="row">
      <div class="col-lg-12">
        <center><img class="img-fluid rounded mb-4" src="images/admin.jpg" alt="" width="900" height="438"></center>
      </div>
      <div class="col-lg-12">
        <h2>Страница администратора</h2>
        <p>Администратор – пользователь, который имеет право на ввод и редактирование данных web-приложения для кадрового агенства "РеКадр", 
        а также, раздачу прав остальным пользователям.</p>      
      </div>
    </div>
    </div>
  </div>
      <!-- Footer -->
  <?php 
  include 'temp/footer_a.php'; 
?>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.prettyPhoto.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/main.js"></script>
</body>
</html>