<?php 
include 'temp/head.php';
include 'temp/header.php'; 
 ?>
<div class="slider">
<div class="container">  
<div class="row">
     <div class="center wow fadeInDown">
        <h2>Кадровое агентство РеКадр - взаимодействие с соискателями:</h2>
		 <h3>Как правило, мы сами находим соискателей и предлагаем вакансии с дальнейшим приглашением на собеседование к нам в офис.</h3>
<p>На собеседовании мы расскажем все о должности и будущем месте работы, о требованиях, поможем подготовиться к реальному интервью. Если первичное собеседование прошло успешно, Вы наверняка сможете блестяще пройти повторное собеседование в компании работодателя и получить желаемую должность.</p>

    </div>
       <div class="col-lg-12">
	   	   
	   <div class="center wow fadeInDown">
	   
	  <h2> Услуги для соискателей</h2>
	  
       <div class="justify wow fadeInDown">
	      
       <p> К поиску новой работы необходимо отнестись с максимальной ответственностью, тк от этого напрямую будет зависеть ваше будущее. 
	   Чтобы поиск новой работы был максимально эффективным, необходимо этим заниматься основательно, и тогда Вы будете довольны достигнутым результатом. 
	   Поближе к дому, с гибким графиком, нужная и важная, по душе, с отличными перспективами </p>
	  </div>    </div>
    <p> <font size="3" color="#191970" face="Arial">Вас интересуют услуги для соискателей от агентства «Фаворит» ?</p>
	
   <center> <p> <font size="3" color="red" face="Arial">Добавить свое резюме в собственную базу кадрового агентства РеКадр: </p></center> 
	<center><a href="soisk.php"> <img class="img-fluid rounded mb-4" src="images/send_resume.png" alt="" ></a></center> 
	</div>
   
    <br>
    </div>
  </div>
  </div>
 
  <!-- /.container -->
    <!-- Footer -->
    <?php 
  include 'temp/footer.php'; 
?>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.prettyPhoto.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/main.js"></script>

</body>

</html>