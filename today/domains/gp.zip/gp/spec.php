<?php 
include 'temp/head.php';
include 'temp/header_s.php'; 
 ?>
 <br>
  <div class="slider">
    <div class="container">
       <div class="center wow fadeInDown">
        <h2>Страница специалиста</h2>
       </div>
     <div class="row">
      <div class="col-lg-12">
        <center><img class="img-fluid rounded mb-4" src="images/sp.jpg" alt="" ></center>
      </div>
     <div class="col-lg-12">
        <h2>Страница специалиста</h2>
        <p>Специалист поможет Вам пройти собеседования и составить анкету, наиболее полно отражающую ваши профессиональные достоинства и 
        достижения.</p>  
        <p>В ходе собеседования ОБСУДИТ Ваш опыт работы, выявит Ваши профессиональные навыки, личные предпочтения, мотивацию.</p>
        <p>Выдаст направления к работодателю.</p>    
     </div>
     </div>
    </div>
  </div>
        <!-- Footer -->
        <?php 
          include 'temp/footer_s.php'; 
        ?>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.prettyPhoto.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/main.js"></script>
</body>
</html>