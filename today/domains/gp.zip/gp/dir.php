<?php 
include 'temp/head.php';
include 'temp/header_d.php'; 
 ?>
  <br>
 <br>
 <br>
 <br>
  <div class="slider">
    <div class="container">
     <div class="center wow fadeInDown">
        <h2>Страница директора</h2>
     </div>
     <div class="row">
      <div class="col-lg-12">
        <center><img class="img-fluid rounded mb-4" src="images/12.jpg" alt="" width="1140" height="550"></center>
      </div>
      <div class="col-lg-12">
        <h2>Страница директора</h2>
        <p>Директор – пользователь, который имеет право на просмотр отчётов.</p>      
      </div>
    </div>
    </div>
  </div>
      <!-- Footer -->
  <?php 
  include 'temp/footer_d.php'; 
?>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.prettyPhoto.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/main.js"></script>
</body>
</html>